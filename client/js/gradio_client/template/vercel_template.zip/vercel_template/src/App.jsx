import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Header from "./components/Header";
import Hero from "./components/Hero";
import Features from "./components/Features";
import Upload from "./components/Upload";
import Preview from "./components/Preview";
import Footer from "./components/Footer";
import { useTheme } from "./hooks/useTheme";
import "./styles/globals.css";

function App() {
  const { theme, toggleTheme } = useTheme();

  // State for images
  const [originalImage, setOriginalImage] = useState(null);
  const [processedImage, setProcessedImage] = useState(null);

  // Reset to upload another image
  const reset = () => {
    setOriginalImage(null);
    setProcessedImage(null);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 },
    },
  };

  return (
    <motion.div
      className={`app ${theme}`}
      initial="hidden"
      animate="visible"
      variants={containerVariants}
    >
      <Header theme={theme} toggleTheme={toggleTheme} />

      <main>
        <Hero />
        <Features />

        {/* If no processed image yet, show upload section */}
        {!processedImage ? (
          <Upload
            setOriginalImage={setOriginalImage}
            setProcessedImage={setProcessedImage}
          />
        ) : (
          <AnimatePresence mode="wait">
            <Preview
              originalImage={originalImage}
              processedImage={processedImage}
              reset={reset}
            />
          </AnimatePresence>
        )}
      </main>

      <Footer />
    </motion.div>
  );
}

export default App;
