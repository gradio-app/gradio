// src/components/ThemeToggle/ThemeToggle.js
import React from 'react';
import { motion } from 'framer-motion';

const ThemeToggle = ({ theme, toggleTheme }) => {
  return (
    <motion.button
      className="theme-toggle"
      onClick={toggleTheme}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
      animate={{
        rotate: theme === 'dark' ? 180 : 0
      }}
      transition={{ duration: 0.3 }}
    >
      <motion.div
        className="theme-icon"
        animate={{
          scale: [1, 1.2, 1]
        }}
        transition={{ duration: 0.3 }}
      >
        {theme === 'light' ? '🌙' : '☀️'}
      </motion.div>
    </motion.button>
  );
};

export default ThemeToggle;