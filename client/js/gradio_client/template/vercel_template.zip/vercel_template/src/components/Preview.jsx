// src/components/Preview/Preview.jsx
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

const Preview = ({ originalImage, processedImage, reset }) => {
  const [activeTab, setActiveTab] = useState("original");

  const downloadImage = () => {
    const link = document.createElement("a");
    link.href = processedImage;
    link.download = "background-removed.png";
    link.click();
  };

  const containerVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, staggerChildren: 0.1 },
    },
    exit: { opacity: 0, y: -50, transition: { duration: 0.4 } },
  };

  return (
    <motion.section
      className="preview"
      initial="hidden"
      animate="visible"
      exit="exit"
      variants={containerVariants}
    >
      <motion.h2>Your Result</motion.h2>

      <div className="preview-tabs">
        {["original", "processed"].map((tab) => (
          <motion.button
            key={tab}
            className={`tab ${activeTab === tab ? "active" : ""}`}
            onClick={() => setActiveTab(tab)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {tab === "original" ? "Original" : "Background Removed"}
          </motion.button>
        ))}
      </div>

      <div className="preview-content">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            className="preview-image"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.1 }}
            transition={{ duration: 0.3 }}
          >
            <img
              src={activeTab === "original" ? originalImage : processedImage}
              alt={activeTab === "original" ? "Original" : "Processed"}
            />
          </motion.div>
        </AnimatePresence>
      </div>

      <motion.div className="preview-actions">
        <motion.button
          className="download-button"
          onClick={downloadImage}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Download Result
        </motion.button>
        <motion.button
          className="secondary-button"
          onClick={reset}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Process Another
        </motion.button>
      </motion.div>
    </motion.section>
  );
};

export default Preview;
