// src/components/Header/Header.js
import React from 'react';
import { motion } from 'framer-motion';
import ThemeToggle from './ThemeToggle';

const Header = ({ theme, toggleTheme }) => {
  const navItems = ['Home', 'Features'];

  const scrollToSection = (section) => {
    const element = document.getElementById(section.toLowerCase().replace(' ', '-'));
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <motion.header
      className="header"
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
    >
      <nav className="nav">
        <motion.div
          className="logo"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <span className="logo-text">Split Fork</span>
        </motion.div>

        <ul className="nav-links">
          {navItems.map((item, index) => (
            <motion.li
              key={item}
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <button
                onClick={() => scrollToSection(item)}
                className="nav-link"
              >
                {item}
              </button>
            </motion.li>
          ))}
        </ul>

        <div className="nav-actions">
        <ThemeToggle theme={theme} toggleTheme={toggleTheme} />
        <motion.button
          className="cta-button"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => {
            const section = document.querySelector("#upload");
            if (section) {
              section.scrollIntoView({ behavior: "smooth" });
            }
          }}
        >
          Get Started
        </motion.button>
      </div>

      </nav>
    </motion.header>
  );
};

export default Header;