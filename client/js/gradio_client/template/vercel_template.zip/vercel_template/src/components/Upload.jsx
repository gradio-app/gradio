// src/components/Upload/Upload.jsx
import React, { useRef } from "react";
import { motion } from "framer-motion";
import { removeBackground } from "../utils/inference"; // 👈 Import inference function

const Upload = ({ setOriginalImage, setProcessedImage }) => {
  const fileInputRef = useRef();
  const [uploadedImage, setUploadedImage] = React.useState(null);
  const [isProcessing, setIsProcessing] = React.useState(false);

  const handleDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith("image/")) {
      const previewUrl = URL.createObjectURL(file);
      setUploadedImage(previewUrl);
      setOriginalImage(previewUrl);
      fileInputRef.current.file = file;
    }
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      const previewUrl = URL.createObjectURL(file);
      setUploadedImage(previewUrl);
      setOriginalImage(previewUrl);
      fileInputRef.current.file = file;
    }
  };

  const handleProcess = async () => {
    const file = fileInputRef.current.file;
    if (!file) return;
    setIsProcessing(true);
    try {
      const resultUrl = await removeBackground(file);
      setProcessedImage(resultUrl);
    } catch (err) {
      console.error("Inference failed:", err);
      alert("Error removing background. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const dragAreaVariants = {
    initial: { scale: 1 },
    hover: { scale: 1.02 },
    drag: { scale: 0.98 },
  };

  return (
    <section className="upload" id="upload">
      <motion.div
        className="upload-container"
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
      >
        <h2>Remove Background in One Click</h2>
        <p>Upload your image and let AI do the magic</p>

        <motion.div
          className="upload-area"
          onDrop={handleDrop}
          onDragOver={(e) => e.preventDefault()}
          onClick={() => fileInputRef.current?.click()}
          variants={dragAreaVariants}
          initial="initial"
          whileHover="hover"
          whileDrag="drag"
          drag
          dragConstraints={{ top: 0, left: 0, right: 0, bottom: 0 }}
          dragElastic={0.1}
        >
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileSelect}
            accept="image/*"
            style={{ display: "none" }}
          />

          {uploadedImage ? (
            <motion.div
              className="upload-preview"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
            >
              <img src={uploadedImage} alt="Upload preview" />
            </motion.div>
          ) : (
            <div className="upload-placeholder">
              <motion.div
                className="upload-icon"
                animate={{
                  y: [0, -10, 0],
                  scale: [1, 1.1, 1],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              >
                📁
              </motion.div>
              <p>Drag & drop your image here or click to browse</p>
              <span>Supports: JPG, PNG, WebP (Max 10MB)</span>
            </div>
          )}
        </motion.div>

        <motion.button
          className={`process-button ${isProcessing ? "processing" : ""}`}
          onClick={handleProcess}
          disabled={!uploadedImage || isProcessing}
          whileHover={{
            scale: uploadedImage && !isProcessing ? 1.05 : 1,
          }}
          whileTap={{
            scale: uploadedImage && !isProcessing ? 0.95 : 1,
          }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          {isProcessing ? (
            <motion.span
              animate={{ rotate: 360 }}
              transition={{
                duration: 1,
                repeat: Infinity,
                ease: "linear",
              }}
            >
              ⏳
            </motion.span>
          ) : (
            "Remove Background"
          )}
          {isProcessing ? " Processing..." : ""}
        </motion.button>
      </motion.div>
    </section>
  );
};

export default Upload;
