import { Client, handle_file } from "@gradio/client";

const SPACE_NAME = "w-samik/background_remover"; // Replace with your actual Space name

let app;

export async function connectClient() {
  if (!app) {
    app = await Client.connect(SPACE_NAME);
  }
  return app;
}

export async function removeBackground(file) {
  const app = await connectClient();
  const result = await app.predict(0, [handle_file(file)]);
  return result.data[0].url; // The processed image URL
}
