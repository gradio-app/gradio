from gradio.interface import *  # This makes it possible to import `Interface` as `gradio.Interface`.
