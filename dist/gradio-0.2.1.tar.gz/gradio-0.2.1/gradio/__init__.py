from gradio.interface import Interface  # This makes Interface importable as gradio.Interface.
