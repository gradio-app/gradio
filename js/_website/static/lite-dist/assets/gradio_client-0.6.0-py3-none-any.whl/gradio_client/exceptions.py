class SerializationSetupError(ValueError):
    """Raised when a serializers cannot be set up correctly."""

    pass
